# Change Logs

## tiger-compiler-2021-fall(1.1.0)

- Refactor into modern C++ style.
- Use RAII to manage the lifetimes and GC of objects.
- Replace lisp-style lists with the STL lists.
- Release the lab environment on DockerHub.

## tiger-compiler-2019-fall(1.0.3)

- Complement missing function in canon.
- Fix compile-errors in main.cc.

## tiger-compiler-2019-fall(1.0.2)

- Delete deprecated grade scripts.


## tiger-compiler-2019-fall(1.0.1)

- Modify test scripts to prompt zero scores if the testcases and refs folders can't be appropriately linked.

- Add change logs file.

## tiger-compiler-2019-fall(1.0.0)

- The first published version.
